"""CICIDS2017 feature definitions and ordering."""
from __future__ import annotations

# Canonical feature order matching CICIDS2017 dataset columns
CICIDS2017_FEATURES = [
    "destination_port", "flow_duration", "total_fwd_packets", "total_bwd_packets",
    "total_length_fwd_packets", "total_length_bwd_packets",
    "fwd_packet_length_max", "fwd_packet_length_min", "fwd_packet_length_mean", "fwd_packet_length_std",
    "bwd_packet_length_max", "bwd_packet_length_min", "bwd_packet_length_mean", "bwd_packet_length_std",
    "flow_bytes_per_sec", "flow_packets_per_sec",
    "flow_iat_mean", "flow_iat_std", "flow_iat_max", "flow_iat_min",
    "fwd_iat_total", "fwd_iat_mean", "fwd_iat_std", "fwd_iat_max", "fwd_iat_min",
    "bwd_iat_total", "bwd_iat_mean", "bwd_iat_std", "bwd_iat_max", "bwd_iat_min",
    "fwd_psh_flags", "bwd_psh_flags", "fwd_urg_flags", "bwd_urg_flags",
    "fwd_header_length", "bwd_header_length",
    "fwd_packets_per_sec", "bwd_packets_per_sec",
    "min_packet_length", "max_packet_length", "packet_length_mean", "packet_length_std", "packet_length_variance",
    "fin_flag_count", "syn_flag_count", "rst_flag_count", "psh_flag_count",
    "ack_flag_count", "urg_flag_count", "cwe_flag_count", "ece_flag_count",
    "down_up_ratio", "average_packet_size", "avg_fwd_segment_size", "avg_bwd_segment_size",
    "fwd_avg_bytes_per_bulk", "fwd_avg_packets_per_bulk", "fwd_avg_bulk_rate",
    "bwd_avg_bytes_per_bulk", "bwd_avg_packets_per_bulk", "bwd_avg_bulk_rate",
    "subflow_fwd_packets", "subflow_fwd_bytes", "subflow_bwd_packets", "subflow_bwd_bytes",
    "init_win_bytes_forward", "init_win_bytes_backward", "act_data_pkt_fwd", "min_seg_size_forward",
    "active_mean", "active_std", "active_max", "active_min",
    "idle_mean", "idle_std", "idle_max", "idle_min",
]

FEATURE_COUNT = len(CICIDS2017_FEATURES)  # 77 flow features (canonical order for this codebase)

ATTACK_CLASSES = [
    "BENIGN",
    "DoS Hulk",
    "PortScan",
    "DDoS",
    "DoS GoldenEye",
    "FTP-Patator",
    "SSH-Patator",
    "DoS slowloris",
    "DoS Slowhttptest",
    "Bot",
    "Web Attack - Brute Force",
    "Web Attack - XSS",
    "Infiltration",
    "Web Attack - Sql Injection",
    "Heartbleed",
]

SEVERITY_MAP = {
    "BENIGN": "info",
    "DoS Hulk": "critical",
    "PortScan": "medium",
    "DDoS": "critical",
    "DoS GoldenEye": "high",
    "FTP-Patator": "high",
    "SSH-Patator": "high",
    "DoS slowloris": "high",
    "DoS Slowhttptest": "high",
    "Bot": "critical",
    "Web Attack - Brute Force": "high",
    "Web Attack - XSS": "medium",
    "Infiltration": "critical",
    "Web Attack - Sql Injection": "critical",
    "Heartbleed": "critical",
}
